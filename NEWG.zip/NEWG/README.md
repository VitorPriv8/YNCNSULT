# 🤖 IsaRobot WhatsApp Bot

Bot WhatsApp avançado para consultas de dados brasileiros com múltiplos métodos de conexão. Suporta API REST via SpiderX, conexão Baileys e é totalmente compatível com Termux.

## ✨ Principais Recursos

- 📡 **Conexão via API REST** (api.spiderx.com.br) com código de pareamento
- 📱 **Compatibilidade total com Termux** e dispositivos móveis
- 🔐 **Sistema de tokens configuráveis** via arquivos .env
- 🚀 **Menu interativo** para seleção de método de conexão
- 💬 **24+ comandos de consulta** de dados brasileiros
- 🛡️ **Rate limiting** e validação robusta de dados
- 📊 **Logs estruturados** com rotação automática

## 🚀 Início Rápido

### 1. Instalação
```bash
# Clone o repositório
git clone <seu-repo>
cd isarobot-whatsapp-bot

# Instale as dependências
npm install
```

### 2. Configuração
1. **Configure o arquivo .env**:
   ```bash
   cp .env.example .env
   nano .env
   ```

2. **Configure seus tokens**:
   - `API_TOKEN`: Token da API SpiderX (api.spiderx.com.br)
   - `API_KEY`: Token da sua API de consultas
   - `PHONE_NUMBER`: Seu número do WhatsApp

### 3. Execução
```bash
node index.js
```

O bot apresentará um menu interativo para escolher o método de conexão:

#### Opções de Conexão:
- **API REST** (Recomendado para Termux): Usa api.spiderx.com.br
- **QR Code**: Conexão tradicional via código QR
- **Código de Pareamento**: Para ambientes sem QR scanner

### 2. Comandos Disponíveis

#### 📋 Consultas de CPF
- `/cpf 12345678901` - Consulta CPF básico
- `/cpfsus 12345678901` - Consulta CPF através do SUS
- `/cpffull 12345678901` - Consulta completa do CPF

#### 📞 Consultas de Telefone
- `/telefone 5511999999999` - Consulta básica por telefone
- `/telefone2 5511999999999` - Consulta completa por telefone

#### 👤 Consultas por Nome
- `/nome João da Silva` - Consulta por nome
- `/nome2 João Silva 01234567` - Consulta nome + CEP
- `/nome3 João Silva SP` - Consulta nome + UF
- `/nome4 João Silva 01/01/1990` - Consulta nome + data nascimento

#### 👩 Consultas Familiares
- `/mae Maria da Silva` - Consulta por nome da mãe
- `/mae2 Maria da Silva` - Consulta completa por nome da mãe

#### 📧 Consultas de Email
- `/email joao@email.com` - Consulta por email

#### 📍 Consultas de Endereço
- `/cep 01234567` - Consulta por CEP
- `/cep2 01234567` - Consulta completa por CEP

#### 🆔 Consultas de Documentos
- `/rg 123456789` - Consulta por RG
- `/pis 12345678901` - Consulta por PIS
- `/cns 123456789012345` - Consulta por CNS

#### 💰 Consultas Financeiras
- `/score 12345678901` - Consulta score do CPF
- `/renda 12345678901` - Consulta renda estimada
- `/poderaquisitivo 12345678901` - Consulta poder aquisitivo

#### 🗳️ Consultas Eleitorais
- `/titulo 12345678901` - Consulta título de eleitor
- `/chavepix 12345678901` - Consulta chaves PIX

#### 🚗 Consultas Veiculares
- `/placa ABC1234` - Consulta por placa
- `/chassi 9BWZZZ377VT004251` - Consulta por chassi
- `/motor 123456789` - Consulta por número do motor
- `/renavam 12345678901` - Consulta por RENAVAM

#### 📷 Consultas de Foto de Condutor
- `/foto CE 12345678901` - Foto condutor Ceará
- `/foto PR 12345678901` - Foto condutor Paraná
- `/foto ES 12345678901` - Foto condutor Espírito Santo
- `/foto RJ 12345678901` - Foto condutor Rio de Janeiro

### 3. Configuração da API

#### Estrutura dos Endpoints

O bot espera que sua API tenha endpoints no formato:

```
GET /api/consulta/cpf?cpf=12345678901
GET /api/consulta/telefone?telefone=5511999999999
GET /api/consulta/nome?nome=João da Silva
```

#### Exemplo de Resposta da API

```json
{
  "nome": "João da Silva",
  "cpf": "12345678901",
  "data_nascimento": "01/01/1990",
  "nome_mae": "Maria da Silva",
  "situacao": "Regular"
}
```

### 4. Configuração Avançada

#### Rate Limiting
- `RATE_LIMIT_WINDOW`: Janela de tempo em ms (padrão: 60000 = 1 minuto)
- `RATE_LIMIT_MAX_REQUESTS`: Máximo de requests por janela (padrão: 10)

#### Logs
- `LOG_LEVEL`: Nível de log (debug, info, warn, error)
- Logs são salvos em `logs/bot.log` e `logs/error.log`

#### Comandos Personalizados
- Edite `config/commands.json` para adicionar/modificar comandos
- Edite `config/api-endpoints.json` para configurar endpoints da API

## 📁 Estrutura do Projeto

```
├── src/
│   ├── bot/whatsapp.js          # Cliente WhatsApp
│   ├── commands/commandHandler.js # Processador de comandos
│   ├── services/
│   │   ├── consultaApi.js       # Cliente da API
│   │   └── logger.js            # Sistema de logs
│   └── utils/
│       ├── validators.js        # Validadores de dados
│       └── formatters.js        # Formatadores de resposta
├── config/
│   ├── commands.json            # Configuração dos comandos
│   └── api-endpoints.json       # Configuração dos endpoints
├── logs/                        # Arquivos de log
├── auth/                        # Dados de autenticação WhatsApp
└── index.js                     # Ponto de entrada
```

## 🔒 Segurança

- Nunca compartilhe seu arquivo `.env`
- Use tokens de API com permissões limitadas
- Configure rate limiting adequado
- Monitore os logs regularmente

## 🛠️ Desenvolvimento

Para contribuir com o projeto:

1. Faça um fork do repositório
2. Crie uma branch para sua feature
3. Implemente suas mudanças
4. Teste thoroughly
5. Abra um Pull Request

## 📞 Suporte

Em caso de problemas:
1. Verifique os logs em `logs/`
2. Confirme a configuração da API
3. Teste a conectividade com WhatsApp
4. Verifique as permissões dos arquivos