const axios = require('axios');
const logger = require('../services/logger');
const QRCode = require('qrcode-terminal');
const qrcode = require('qrcode');
const fs = require('fs');
const path = require('path');

class APIConnection {
    constructor() {
        this.apiUrl = process.env.API_BASE_URL || 'https://api.spiderx.com.br';
        this.token = process.env.API_TOKEN || '';
        this.sessionId = null;
        this.connected = false;
        this.phoneNumber = null;
        this.qrPath = path.join(__dirname, '../../auth/qr.png');
    }

    // Configurar API
    setApiConfig(apiUrl, token) {
        this.apiUrl = apiUrl;
        this.token = token;
        logger.info(`API configurada: ${this.apiUrl}`);
    }

    // Headers para requisições
    getHeaders() {
        return {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.token}`,
            'User-Agent': 'IsaRobot-WhatsApp-Bot/1.0'
        };
    }

    // Inicializar sessão na API
    async initializeSession() {
        try {
            logger.info('Iniciando sessão na API...');
            
            const response = await axios.post(`${this.apiUrl}/api/session/create`, {
                name: 'IsaRobot',
                webhook: process.env.WEBHOOK_URL || null
            }, {
                headers: this.getHeaders(),
                timeout: 30000
            });

            if (response.data.success) {
                this.sessionId = response.data.sessionId;
                logger.info(`Sessão criada: ${this.sessionId}`);
                return this.sessionId;
            } else {
                throw new Error(`Erro na API: ${response.data.message}`);
            }
        } catch (error) {
            logger.error('Erro ao criar sessão:', error.message);
            throw error;
        }
    }

    // Conectar via QR Code
    async connectWithQR() {
        try {
            if (!this.sessionId) {
                await this.initializeSession();
            }

            logger.info('Solicitando QR Code...');
            
            const response = await axios.get(`${this.apiUrl}/api/session/qr/${this.sessionId}`, {
                headers: this.getHeaders(),
                timeout: 30000
            });

            if (response.data.success && response.data.qr) {
                const qrData = response.data.qr;
                
                // Exibir QR no terminal
                console.log('\n' + '='.repeat(50));
                console.log('📱 ESCANEIE O QR CODE ABAIXO:');
                console.log('='.repeat(50));
                QRCode.generate(qrData, { small: true });
                console.log('='.repeat(50) + '\n');

                // Salvar QR como imagem
                await this.saveQRImage(qrData);
                
                // Aguardar conexão
                await this.waitForConnection();
                
                return true;
            } else {
                throw new Error('QR Code não recebido da API');
            }
        } catch (error) {
            logger.error('Erro ao conectar via QR:', error.message);
            throw error;
        }
    }

    // Conectar via código de pareamento
    async connectWithPairingCode(phoneNumber) {
        try {
            if (!phoneNumber) {
                throw new Error('Número de telefone é obrigatório');
            }

            // Limpar formato do número
            const cleanNumber = phoneNumber.replace(/[^\d]/g, '');
            if (cleanNumber.length < 10 || cleanNumber.length > 15) {
                throw new Error('Formato de número inválido');
            }

            this.phoneNumber = cleanNumber;

            if (!this.sessionId) {
                await this.initializeSession();
            }

            logger.info(`Solicitando código de pareamento para: +${cleanNumber}`);
            
            const response = await axios.post(`${this.apiUrl}/api/session/pairing-code`, {
                sessionId: this.sessionId,
                phoneNumber: cleanNumber
            }, {
                headers: this.getHeaders(),
                timeout: 30000
            });

            if (response.data.success && response.data.code) {
                const pairingCode = response.data.code;
                
                console.log('\n' + '='.repeat(50));
                console.log(`📱 CÓDIGO DE PAREAMENTO: ${pairingCode}`);
                console.log('👆 Digite este código no WhatsApp para conectar');
                console.log(`📞 Número: +${cleanNumber}`);
                console.log('='.repeat(50) + '\n');

                // Aguardar conexão
                await this.waitForConnection();
                
                return pairingCode;
            } else {
                throw new Error(`Erro ao obter código: ${response.data.message}`);
            }
        } catch (error) {
            logger.error('Erro ao conectar via código:', error.message);
            throw error;
        }
    }

    // Salvar QR como imagem
    async saveQRImage(qrData) {
        try {
            await qrcode.toFile(this.qrPath, qrData, {
                width: 300,
                margin: 2
            });
            logger.info(`QR Code salvo em: ${this.qrPath}`);
        } catch (error) {
            logger.warn('Não foi possível salvar QR como imagem:', error.message);
        }
    }

    // Aguardar conexão
    async waitForConnection(timeout = 60000) {
        return new Promise((resolve, reject) => {
            const startTime = Date.now();
            const interval = setInterval(async () => {
                try {
                    const status = await this.getConnectionStatus();
                    
                    if (status.connected) {
                        clearInterval(interval);
                        this.connected = true;
                        
                        // Limpar QR salvo
                        if (fs.existsSync(this.qrPath)) {
                            fs.unlinkSync(this.qrPath);
                        }
                        
                        logger.info('✅ Conectado com sucesso!');
                        if (status.number) {
                            logger.info(`📱 Número conectado: +${status.number}`);
                        }
                        
                        resolve(status);
                    } else if (Date.now() - startTime > timeout) {
                        clearInterval(interval);
                        reject(new Error('Timeout ao aguardar conexão'));
                    }
                } catch (error) {
                    if (Date.now() - startTime > timeout) {
                        clearInterval(interval);
                        reject(error);
                    }
                }
            }, 2000); // Verificar a cada 2 segundos
        });
    }

    // Verificar status da conexão
    async getConnectionStatus() {
        try {
            if (!this.sessionId) {
                return { connected: false };
            }

            const response = await axios.get(`${this.apiUrl}/api/session/status/${this.sessionId}`, {
                headers: this.getHeaders(),
                timeout: 10000
            });

            return {
                connected: response.data.connected || false,
                number: response.data.number || null,
                status: response.data.status || 'unknown'
            };
        } catch (error) {
            logger.error('Erro ao verificar status:', error.message);
            return { connected: false, error: error.message };
        }
    }

    // Enviar mensagem
    async sendMessage(chatId, message) {
        try {
            if (!this.connected || !this.sessionId) {
                throw new Error('Bot não está conectado');
            }

            const response = await axios.post(`${this.apiUrl}/api/message/send`, {
                sessionId: this.sessionId,
                chatId: chatId,
                message: message
            }, {
                headers: this.getHeaders(),
                timeout: 15000
            });

            if (response.data.success) {
                logger.info(`Mensagem enviada para ${chatId}`);
                return response.data;
            } else {
                throw new Error(`Erro ao enviar: ${response.data.message}`);
            }
        } catch (error) {
            logger.error('Erro ao enviar mensagem:', error.message);
            throw error;
        }
    }

    // Configurar webhook para receber mensagens
    async setupWebhook(webhookUrl) {
        try {
            if (!this.sessionId) {
                throw new Error('Sessão não inicializada');
            }

            const response = await axios.post(`${this.apiUrl}/api/session/webhook`, {
                sessionId: this.sessionId,
                webhookUrl: webhookUrl
            }, {
                headers: this.getHeaders(),
                timeout: 15000
            });

            if (response.data.success) {
                logger.info(`Webhook configurado: ${webhookUrl}`);
                return true;
            } else {
                throw new Error(`Erro ao configurar webhook: ${response.data.message}`);
            }
        } catch (error) {
            logger.error('Erro ao configurar webhook:', error.message);
            throw error;
        }
    }

    // Desconectar sessão
    async disconnect() {
        try {
            if (this.sessionId) {
                await axios.delete(`${this.apiUrl}/api/session/${this.sessionId}`, {
                    headers: this.getHeaders(),
                    timeout: 10000
                });
                
                logger.info('Sessão desconectada');
                this.sessionId = null;
                this.connected = false;
            }
        } catch (error) {
            logger.error('Erro ao desconectar:', error.message);
        }
    }

    // Obter informações da conta
    async getAccountInfo() {
        try {
            const response = await axios.get(`${this.apiUrl}/api/session/info/${this.sessionId}`, {
                headers: this.getHeaders(),
                timeout: 10000
            });

            return response.data;
        } catch (error) {
            logger.error('Erro ao obter info da conta:', error.message);
            return null;
        }
    }

    // Verificar se está conectado
    isConnected() {
        return this.connected && this.sessionId;
    }
}

module.exports = APIConnection;