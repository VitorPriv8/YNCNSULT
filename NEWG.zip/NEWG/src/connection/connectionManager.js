const makeWASocket = require('@whiskeysockets/baileys').default;
const { DisconnectReason, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const path = require('path');
const P = require('pino');
const logger = require('../services/logger');
const QRCode = require('qrcode-terminal');

class ConnectionManager {
    constructor() {
        this.sock = null;
        this.authDir = path.join(__dirname, '../../auth');
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 10;
        this.useQR = true; // Padrão: usar QR code
        this.usePairingCode = false;
        this.phoneNumber = null;
    }

    async initializeConnection(options = {}) {
        try {
            this.useQR = options.useQR !== false;
            this.usePairingCode = options.usePairingCode === true;
            this.phoneNumber = options.phoneNumber;

            // Garantir que o diretório de autenticação existe
            if (!fs.existsSync(this.authDir)) {
                fs.mkdirSync(this.authDir, { recursive: true });
            }

            // Obter versão mais recente do Baileys
            const { version, isLatest } = await fetchLatestBaileysVersion();
            logger.info(`Usando versão do Baileys: ${version}, é a mais recente: ${isLatest}`);

            // Configurar estado de autenticação multi-arquivo
            const { state, saveCreds } = await useMultiFileAuthState(this.authDir);

            // Criar logger compatível para Baileys
            const baileyLogger = P({
                level: 'silent' // Silenciar logs internos do Baileys
            });

            // Configurações do socket
            const socketConfig = {
                version,
                logger: baileyLogger,
                printQRInTerminal: false, // Vamos controlar manualmente
                auth: {
                    creds: state.creds,
                    keys: makeCacheableSignalKeyStore(state.keys, baileyLogger)
                },
                browser: ['IsaRobot Bot', 'Chrome', '4.0.0'],
                generateHighQualityLinkPreview: true,
                defaultQueryTimeoutMs: 60000,
                keepAliveIntervalMs: 30000,
                connectTimeoutMs: 60000,
                qrTimeout: 60000,
                markOnlineOnConnect: true
            };

            // Configuração específica para pareamento
            if (this.usePairingCode && this.phoneNumber) {
                socketConfig.mobile = false;
            }

            this.sock = makeWASocket(socketConfig);

            // Configurar event listeners
            this.sock.ev.on('creds.update', saveCreds);
            this.sock.ev.on('connection.update', this.handleConnectionUpdate.bind(this));
            
            logger.info('Bot configurado e aguardando conexão...');
            
            return this.sock;
        } catch (error) {
            logger.error('Erro ao inicializar conexão:', error);
            throw error;
        }
    }

    async handleConnectionUpdate(update) {
        const { connection, lastDisconnect, qr, isNewLogin } = update;

        // Lidar com QR Code
        if (qr && this.useQR) {
            logger.info('QR Code recebido. Escaneie com o WhatsApp.');
            QRCode.generate(qr, { small: true });
            
            // Salvar QR como imagem também
            try {
                const qrcode = require('qrcode');
                await qrcode.toFile(path.join(this.authDir, 'qr.png'), qr);
                logger.info('QR Code salvo como imagem em: auth/qr.png');
            } catch (err) {
                logger.warn('Não foi possível salvar QR como imagem:', err.message);
            }
        }

        // Lidar com código de pareamento
        if (!this.sock.authState.creds.registered && this.usePairingCode && this.phoneNumber) {
            try {
                const code = await this.sock.requestPairingCode(this.phoneNumber);
                logger.info(`Código de pareamento: ${code}`);
                console.log('\n' + '='.repeat(50));
                console.log(`📱 CÓDIGO DE PAREAMENTO: ${code}`);
                console.log('👆 Digite este código no WhatsApp para conectar');
                console.log('='.repeat(50) + '\n');
            } catch (error) {
                logger.error('Erro ao solicitar código de pareamento:', error);
            }
        }

        // Lidar com mudanças de conexão
        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error instanceof Boom ? 
                lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut : true;
            
            if (shouldReconnect && this.reconnectAttempts < this.maxReconnectAttempts) {
                this.reconnectAttempts++;
                const delay = Math.min(5000 * this.reconnectAttempts, 30000); // Delay crescente até 30s
                
                logger.info(`Tentativa de reconexão ${this.reconnectAttempts}/${this.maxReconnectAttempts} em ${delay}ms`);
                
                setTimeout(() => {
                    this.initializeConnection({
                        useQR: this.useQR,
                        usePairingCode: this.usePairingCode,
                        phoneNumber: this.phoneNumber
                    });
                }, delay);
            } else {
                logger.error('Bot desconectado permanentemente ou máximo de tentativas atingido');
                
                // Se foi logout, limpar credenciais
                if (lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut) {
                    logger.info('Logout detectado. Limpando credenciais...');
                    this.clearAuth();
                }
                
                process.exit(1);
            }
        } else if (connection === 'open') {
            logger.info('✅ Conexão estabelecida com sucesso!');
            this.reconnectAttempts = 0;
            
            // Exibir informações da conta conectada
            const connectedNumber = this.sock.user.id.split(':')[0];
            logger.info(`📱 Conectado como: +${connectedNumber}`);
            
            // Limpar QR code salvo se existir
            const qrPath = path.join(this.authDir, 'qr.png');
            if (fs.existsSync(qrPath)) {
                fs.unlinkSync(qrPath);
            }
        } else if (connection === 'connecting') {
            logger.info('🔄 Conectando ao WhatsApp...');
        }

        // Novo login
        if (isNewLogin) {
            logger.info('🎉 Novo login detectado!');
        }
    }

    // Conectar usando QR Code
    async connectWithQR() {
        logger.info('🔲 Iniciando conexão via QR Code...');
        return await this.initializeConnection({
            useQR: true,
            usePairingCode: false
        });
    }

    // Conectar usando código de pareamento
    async connectWithPairingCode(phoneNumber) {
        if (!phoneNumber) {
            throw new Error('Número de telefone é obrigatório para pareamento');
        }

        // Validar formato do número
        const cleanNumber = phoneNumber.replace(/[^\d]/g, '');
        if (cleanNumber.length < 10 || cleanNumber.length > 15) {
            throw new Error('Formato de número inválido');
        }

        logger.info(`📞 Iniciando conexão via código de pareamento para: +${cleanNumber}`);
        return await this.initializeConnection({
            useQR: false,
            usePairingCode: true,
            phoneNumber: cleanNumber
        });
    }

    // Limpar dados de autenticação
    clearAuth() {
        try {
            if (fs.existsSync(this.authDir)) {
                const files = fs.readdirSync(this.authDir);
                files.forEach(file => {
                    fs.unlinkSync(path.join(this.authDir, file));
                });
                logger.info('Dados de autenticação limpos');
            }
        } catch (error) {
            logger.error('Erro ao limpar autenticação:', error);
        }
    }

    // Verificar se está conectado
    isConnected() {
        return this.sock && this.sock.ws && this.sock.ws.readyState === 1;
    }

    // Obter informações da conexão
    getConnectionInfo() {
        if (!this.sock || !this.sock.user) {
            return null;
        }

        return {
            number: this.sock.user.id.split(':')[0],
            name: this.sock.user.name,
            connected: this.isConnected(),
            reconnectAttempts: this.reconnectAttempts
        };
    }

    // Desconectar
    async disconnect() {
        if (this.sock) {
            try {
                await this.sock.ws.close();
                logger.info('Desconectado do WhatsApp');
            } catch (error) {
                logger.error('Erro ao desconectar:', error);
            }
        }
    }
}

module.exports = ConnectionManager;