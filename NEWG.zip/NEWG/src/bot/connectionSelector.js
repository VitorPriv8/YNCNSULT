const readline = require('readline');
const logger = require('../services/logger');
const APIConnection = require('../connection/apiConnection');
const ConnectionManager = require('../connection/connectionManager');

class ConnectionSelector {
    constructor() {
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        
        this.connectionMethod = process.env.CONNECTION_METHOD || 'api';
        this.phoneNumber = process.env.PHONE_NUMBER || '553799519731';
        this.apiUrl = process.env.WHATSAPP_API_URL || 'https://api.spiderx.com.br';
        this.apiToken = process.env.API_TOKEN || 'dUSDfUa7YFnylgA5m69u';
    }

    // Mostrar menu de seleção
    async showMenu() {
        console.clear();
        console.log('🤖 IsaRobot WhatsApp Bot - Configuração de Conexão\n');
        console.log('📡 Selecione o método de conexão:\n');
        console.log('1️⃣  Conexão via API REST (Recomendado)');
        console.log('    └─ Usa api.spiderx.com.br com código de pareamento');
        console.log('2️⃣  Conexão via QR Code (Baileys)');
        console.log('    └─ Conexão direta via QR code');
        console.log('3️⃣  Conexão via Código de Pareamento (Baileys)');
        console.log('    └─ Conexão direta via código');
        console.log('4️⃣  Configurações');
        console.log('5️⃣  Sair\n');
        
        return this.getUserChoice();
    }

    // Obter escolha do usuário
    async getUserChoice() {
        return new Promise((resolve) => {
            this.rl.question('Escolha uma opção (1-5): ', (answer) => {
                resolve(answer.trim());
            });
        });
    }

    // Obter entrada do usuário
    async getInput(question) {
        return new Promise((resolve) => {
            this.rl.question(question, (answer) => {
                resolve(answer.trim());
            });
        });
    }

    // Conectar via API REST
    async connectViaAPI() {
        try {
            console.log('\n🌐 Configurando conexão via API REST...\n');
            
            if (!this.apiToken || this.apiToken === 'dUSDfUa7YFnylgA5m69u') {
                console.log('⚠️  Token da API não configurado!');
                const token = await this.getInput('Digite seu token da API SpiderX: ');
                if (!token) {
                    throw new Error('Token é obrigatório');
                }
                this.apiToken = token;
            }

            if (!this.phoneNumber || this.phoneNumber.length < 10) {
                const phone = await this.getInput('Digite seu número do WhatsApp (ex: 5511999999999): ');
                if (!phone) {
                    throw new Error('Número de telefone é obrigatório');
                }
                this.phoneNumber = phone.replace(/[^\d]/g, '');
            }

            console.log('🔄 Iniciando conexão...\n');

            const apiConnection = new APIConnection();
            apiConnection.setApiConfig(this.apiUrl, this.apiToken);

            // Conectar via código de pareamento
            await apiConnection.connectWithPairingCode(this.phoneNumber);
            
            return apiConnection;
        } catch (error) {
            logger.error('Erro na conexão via API:', error.message);
            console.log(`\n❌ Erro: ${error.message}\n`);
            throw error;
        }
    }

    // Conectar via QR Code (Baileys)
    async connectViaQR() {
        try {
            console.log('\n📱 Configurando conexão via QR Code...\n');
            
            const connectionManager = new ConnectionManager();
            return await connectionManager.connectWithQR();
        } catch (error) {
            logger.error('Erro na conexão via QR:', error.message);
            console.log(`\n❌ Erro: ${error.message}\n`);
            throw error;
        }
    }

    // Conectar via código de pareamento (Baileys)
    async connectViaPairingCode() {
        try {
            console.log('\n📞 Configurando conexão via código de pareamento...\n');
            
            if (!this.phoneNumber || this.phoneNumber.length < 10) {
                const phone = await this.getInput('Digite seu número do WhatsApp (ex: 5511999999999): ');
                if (!phone) {
                    throw new Error('Número de telefone é obrigatório');
                }
                this.phoneNumber = phone.replace(/[^\d]/g, '');
            }

            const connectionManager = new ConnectionManager();
            return await connectionManager.connectWithPairingCode(this.phoneNumber);
        } catch (error) {
            logger.error('Erro na conexão via código:', error.message);
            console.log(`\n❌ Erro: ${error.message}\n`);
            throw error;
        }
    }

    // Mostrar configurações
    async showSettings() {
        console.clear();
        console.log('⚙️  Configurações Atuais:\n');
        console.log(`📡 API URL: ${this.apiUrl}`);
        console.log(`🔑 Token: ${this.apiToken ? '***configurado***' : 'não configurado'}`);
        console.log(`📱 Telefone: ${this.phoneNumber || 'não configurado'}`);
        console.log(`🔗 Método padrão: ${this.connectionMethod}\n`);

        console.log('Opções:');
        console.log('1️⃣  Alterar API URL');
        console.log('2️⃣  Alterar Token');
        console.log('3️⃣  Alterar Telefone');
        console.log('4️⃣  Voltar ao menu principal\n');

        const choice = await this.getUserChoice();

        switch (choice) {
            case '1':
                this.apiUrl = await this.getInput('Nova API URL: ') || this.apiUrl;
                break;
            case '2':
                this.apiToken = await this.getInput('Novo Token: ') || this.apiToken;
                break;
            case '3':
                this.phoneNumber = await this.getInput('Novo Telefone: ') || this.phoneNumber;
                break;
            case '4':
                return this.start();
        }

        console.log('\n✅ Configuração atualizada!\n');
        await new Promise(resolve => setTimeout(resolve, 2000));
        return this.showSettings();
    }

    // Método principal
    async start() {
        try {
            // Se já tiver método definido no .env, usar automaticamente
            if (this.connectionMethod === 'api' && this.apiToken && this.phoneNumber) {
                console.log('🚀 Usando configuração automática via API...\n');
                return await this.connectViaAPI();
            }

            while (true) {
                const choice = await this.showMenu();

                switch (choice) {
                    case '1':
                        const apiConn = await this.connectViaAPI();
                        this.rl.close();
                        return { connection: apiConn, type: 'api' };
                    
                    case '2':
                        const qrConn = await this.connectViaQR();
                        this.rl.close();
                        return { connection: qrConn, type: 'baileys' };
                    
                    case '3':
                        const pairConn = await this.connectViaPairingCode();
                        this.rl.close();
                        return { connection: pairConn, type: 'baileys' };
                    
                    case '4':
                        await this.showSettings();
                        break;
                    
                    case '5':
                        console.log('\n👋 Saindo...\n');
                        this.rl.close();
                        process.exit(0);
                        break;
                    
                    default:
                        console.log('\n❌ Opção inválida! Tente novamente.\n');
                        await new Promise(resolve => setTimeout(resolve, 2000));
                }
            }
        } catch (error) {
            this.rl.close();
            throw error;
        }
    }

    // Detectar se está rodando no Termux
    static isTermux() {
        return process.env.PREFIX && process.env.PREFIX.includes('termux');
    }

    // Verificar dependências para Termux
    static checkTermuxDependencies() {
        if (this.isTermux()) {
            console.log('📱 Ambiente Termux detectado');
            console.log('✅ Dependências verificadas para Termux');
            
            // Verificar se o Node.js está atualizado
            const nodeVersion = process.version;
            console.log(`📦 Node.js: ${nodeVersion}`);
            
            return true;
        }
        return false;
    }
}

module.exports = ConnectionSelector;