const makeWASocket = require('@whiskeysockets/baileys').default;
const { DisconnectReason, useMultiFileAuthState } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const path = require('path');
const logger = require('../services/logger');
const CommandHandler = require('../commands/commandHandler');

class WhatsAppBot {
    constructor() {
        this.sock = null;
        this.commandHandler = new CommandHandler();
        this.authDir = path.join(__dirname, '../../auth');
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
    }

    async start() {
        try {
            // Garantir que o diretório de autenticação existe
            if (!fs.existsSync(this.authDir)) {
                fs.mkdirSync(this.authDir, { recursive: true });
            }

            const { state, saveCreds } = await useMultiFileAuthState(this.authDir);
            
            // Criar logger compatível com Baileys
            const baileyLogger = {
                level: 'silent', // Silenciar logs do Baileys para evitar problemas
                trace: () => {},
                debug: () => {},
                info: () => {},
                warn: () => {},
                error: () => {},
                child: () => baileyLogger
            };

            this.sock = makeWASocket({
                auth: state,
                logger: baileyLogger,
                defaultQueryTimeoutMs: 60000,
                keepAliveIntervalMs: 30000,
            });

            this.sock.ev.on('creds.update', saveCreds);
            this.sock.ev.on('connection.update', this.handleConnectionUpdate.bind(this));
            this.sock.ev.on('messages.upsert', this.handleMessages.bind(this));
            
            logger.info('Bot configurado e aguardando conexão...');
        } catch (error) {
            logger.error('Erro ao iniciar o bot:', error);
            throw error;
        }
    }

    async handleConnectionUpdate(update) {
        const { connection, lastDisconnect, qr } = update;
        
        if (qr) {
            logger.info('QR Code recebido. Escaneie com o WhatsApp.');
            // Imprimir QR code no terminal manualmente
            const QRCode = require('qrcode-terminal');
            QRCode.generate(qr, { small: true });
        }
        
        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect?.error instanceof Boom) ? 
                lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut : true;
            
            if (shouldReconnect && this.reconnectAttempts < this.maxReconnectAttempts) {
                this.reconnectAttempts++;
                logger.info(`Tentativa de reconexão ${this.reconnectAttempts}/${this.maxReconnectAttempts}`);
                setTimeout(() => this.start(), 5000);
            } else {
                logger.error('Bot desconectado permanentemente');
                process.exit(1);
            }
        } else if (connection === 'open') {
            logger.info('Conexão estabelecida com sucesso!');
            this.reconnectAttempts = 0;
        }
    }

    async handleMessages(m) {
        try {
            const message = m.messages[0];
            if (!message.message || message.key.fromMe) return;

            const messageText = this.extractMessageText(message);
            if (!messageText) return;

            const chatId = message.key.remoteJid;
            const senderId = message.key.participant || chatId;

            logger.info(`Mensagem recebida de ${senderId}: ${messageText}`);

            // Processar comando
            const response = await this.commandHandler.processCommand(messageText, senderId);
            
            if (response) {
                await this.sendMessage(chatId, response);
            }
        } catch (error) {
            logger.error('Erro ao processar mensagem:', error);
        }
    }

    extractMessageText(message) {
        if (message.message.conversation) {
            return message.message.conversation;
        }
        if (message.message.extendedTextMessage) {
            return message.message.extendedTextMessage.text;
        }
        return null;
    }

    async sendMessage(chatId, text) {
        try {
            await this.sock.sendMessage(chatId, { text });
            logger.info(`Mensagem enviada para ${chatId}`);
        } catch (error) {
            logger.error('Erro ao enviar mensagem:', error);
        }
    }
}

module.exports = { WhatsAppBot };
