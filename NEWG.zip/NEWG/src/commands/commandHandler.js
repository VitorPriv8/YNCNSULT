const fs = require('fs');
const path = require('path');
const logger = require('../services/logger');
const ConsultaApi = require('../services/consultaApi');
const { validateCPF, validatePhone, validateEmail, validatePlaca } = require('../utils/validators');
const { formatResponse } = require('../utils/formatters');

class CommandHandler {
    constructor() {
        this.commands = this.loadCommands();
        this.consultaApi = new ConsultaApi();
        this.prefix = process.env.BOT_PREFIX || '/';
        this.userRateLimit = new Map();
    }

    loadCommands() {
        try {
            const configPath = path.join(__dirname, '../../config/commands.json');
            return JSON.parse(fs.readFileSync(configPath, 'utf8'));
        } catch (error) {
            logger.error('Erro ao carregar comandos:', error);
            return {};
        }
    }

    async processCommand(messageText, senderId) {
        try {
            // Verificar rate limiting
            if (!this.checkRateLimit(senderId)) {
                return 'Você está fazendo muitas consultas. Aguarde um momento antes de tentar novamente.';
            }

            // Extrair comando e parâmetros
            const parts = messageText.trim().split(' ');
            const command = parts[0].toLowerCase();
            const params = parts.slice(1);

            // Verificar se é um comando válido
            if (!command.startsWith(this.prefix)) {
                return null;
            }

            const commandName = command.substring(1);
            const commandConfig = this.commands[commandName];

            if (!commandConfig) {
                return this.getHelpMessage();
            }

            // Validar parâmetros
            const validationResult = this.validateCommandParams(commandName, params);
            if (!validationResult.isValid) {
                return validationResult.message;
            }

            // Executar consulta
            const result = await this.executeCommand(commandName, params);
            return formatResponse(commandName, result);

        } catch (error) {
            logger.error('Erro ao processar comando:', error);
            return 'Erro interno. Tente novamente em alguns momentos.';
        }
    }

    checkRateLimit(senderId) {
        const now = Date.now();
        const windowMs = parseInt(process.env.RATE_LIMIT_WINDOW) || 60000;
        const maxRequests = parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 10;

        if (!this.userRateLimit.has(senderId)) {
            this.userRateLimit.set(senderId, { count: 1, resetTime: now + windowMs });
            return true;
        }

        const userLimit = this.userRateLimit.get(senderId);
        
        if (now > userLimit.resetTime) {
            userLimit.count = 1;
            userLimit.resetTime = now + windowMs;
            return true;
        }

        if (userLimit.count >= maxRequests) {
            return false;
        }

        userLimit.count++;
        return true;
    }

    validateCommandParams(commandName, params) {
        const commandConfig = this.commands[commandName];
        
        if (commandConfig.requiredParams && params.length < commandConfig.requiredParams) {
            return {
                isValid: false,
                message: `Uso: ${this.prefix}${commandName} ${commandConfig.usage || ''}\nExemplo: ${commandConfig.example || ''}`
            };
        }

        // Validações específicas por tipo de comando
        switch (commandName) {
            case 'cpf':
            case 'cpfsus':
            case 'cpffull':
                if (!validateCPF(params[0])) {
                    return { isValid: false, message: 'CPF inválido. Digite apenas os números.' };
                }
                break;
            
            case 'telefone':
            case 'telefone2':
                if (!validatePhone(params[0])) {
                    return { isValid: false, message: 'Telefone inválido. Use o formato: 5511999999999' };
                }
                break;
            
            case 'email':
                if (!validateEmail(params[0])) {
                    return { isValid: false, message: 'Email inválido.' };
                }
                break;
            
            case 'placa':
                if (!validatePlaca(params[0])) {
                    return { isValid: false, message: 'Placa inválida. Use o formato: ABC1234 ou ABC1D23' };
                }
                break;
            
            case 'foto':
                const estado = params[0]?.toUpperCase();
                const validStates = (process.env.ESTADOS_FOTO || 'CE,PR,ES,RJ').split(',');
                if (!validStates.includes(estado)) {
                    return { 
                        isValid: false, 
                        message: `Estado inválido. Estados disponíveis: ${validStates.join(', ')}` 
                    };
                }
                if (!validateCPF(params[1])) {
                    return { isValid: false, message: 'CPF inválido para consulta de foto.' };
                }
                break;
        }

        return { isValid: true };
    }

    async executeCommand(commandName, params) {
        try {
            logger.info(`Executando comando: ${commandName} com parâmetros: ${params.join(', ')}`);
            
            switch (commandName) {
                case 'cpf':
                    return await this.consultaApi.consultarCPF(params[0]);
                
                case 'cpfsus':
                    return await this.consultaApi.consultarCPFSUS(params[0]);
                
                case 'cpffull':
                    return await this.consultaApi.consultarCPFFull(params[0]);
                
                case 'telefone':
                    return await this.consultaApi.consultarTelefone(params[0]);
                
                case 'telefone2':
                    return await this.consultaApi.consultarTelefoneFull(params[0]);
                
                case 'nome':
                    return await this.consultaApi.consultarNome(params.join(' '));
                
                case 'nome2':
                    return await this.consultaApi.consultarNomeCEP(params[0], params[1]);
                
                case 'nome3':
                    return await this.consultaApi.consultarNomeUF(params[0], params[1]);
                
                case 'nome4':
                    return await this.consultaApi.consultarNomeDataNasc(params[0], params[1]);
                
                case 'mae':
                    return await this.consultaApi.consultarMae(params.join(' '));
                
                case 'mae2':
                    return await this.consultaApi.consultarMaeFull(params.join(' '));
                
                case 'email':
                    return await this.consultaApi.consultarEmail(params[0]);
                
                case 'cep':
                    return await this.consultaApi.consultarCEP(params[0]);
                
                case 'cep2':
                    return await this.consultaApi.consultarCEPFull(params[0]);
                
                case 'rg':
                    return await this.consultaApi.consultarRG(params[0]);
                
                case 'pis':
                    return await this.consultaApi.consultarPIS(params[0]);
                
                case 'cns':
                    return await this.consultaApi.consultarCNS(params[0]);
                
                case 'score':
                    return await this.consultaApi.consultarScore(params[0]);
                
                case 'renda':
                    return await this.consultaApi.consultarRenda(params[0]);
                
                case 'poderaquisitivo':
                    return await this.consultaApi.consultarPoderAquisitivo(params[0]);
                
                case 'titulo':
                    return await this.consultaApi.consultarTituloEleitor(params[0]);
                
                case 'chavepix':
                    return await this.consultaApi.consultarChavePix(params[0]);
                
                case 'placa':
                    return await this.consultaApi.consultarPlaca(params[0]);
                
                case 'chassi':
                    return await this.consultaApi.consultarChassi(params[0]);
                
                case 'motor':
                    return await this.consultaApi.consultarMotor(params[0]);
                
                case 'renavam':
                    return await this.consultaApi.consultarRenavam(params[0]);
                
                case 'foto':
                    return await this.consultaApi.consultarFotoCondutor(params[0], params[1]);
                
                default:
                    throw new Error(`Comando não implementado: ${commandName}`);
            }
        } catch (error) {
            logger.error(`Erro ao executar comando ${commandName}:`, error);
            throw error;
        }
    }

    getHelpMessage() {
        const commandsList = Object.entries(this.commands)
            .map(([cmd, config]) => `${this.prefix}${cmd} - ${config.description}`)
            .join('\n');
        
        return `*IsaRobot - Comandos Disponíveis:*\n\n${commandsList}\n\n_Use ${this.prefix}comando parâmetros para fazer consultas._`;
    }
}

module.exports = CommandHandler;
