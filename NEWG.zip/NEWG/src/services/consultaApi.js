const axios = require('axios');
const fs = require('fs');
const path = require('path');
const logger = require('./logger');

class ConsultaApi {
    constructor() {
        this.baseURL = process.env.API_BASE_URL || 'https://api.example.com';
        this.apiKey = process.env.API_KEY || 'default_key';
        this.timeout = parseInt(process.env.API_TIMEOUT) || 30000;
        this.endpoints = this.loadEndpoints();
        
        this.client = axios.create({
            baseURL: this.baseURL,
            timeout: this.timeout,
            headers: {
                'Authorization': `Bearer ${this.apiKey}`,
                'Content-Type': 'application/json',
                'User-Agent': 'IsaRobot/1.0'
            }
        });

        // Interceptor para logs
        this.client.interceptors.request.use(
            (config) => {
                logger.info(`Fazendo requisição para: ${config.url}`);
                return config;
            },
            (error) => {
                logger.error('Erro na requisição:', error);
                return Promise.reject(error);
            }
        );

        this.client.interceptors.response.use(
            (response) => {
                logger.info(`Resposta recebida: ${response.status}`);
                return response;
            },
            (error) => {
                logger.error('Erro na resposta:', error.message);
                return Promise.reject(error);
            }
        );
    }

    loadEndpoints() {
        try {
            const configPath = path.join(__dirname, '../../config/api-endpoints.json');
            return JSON.parse(fs.readFileSync(configPath, 'utf8'));
        } catch (error) {
            logger.error('Erro ao carregar endpoints:', error);
            return {};
        }
    }

    async makeRequest(endpoint, params = {}) {
        try {
            const endpointConfig = this.endpoints[endpoint];
            if (!endpointConfig) {
                throw new Error(`Endpoint não configurado: ${endpoint}`);
            }

            let url = endpointConfig.path;
            const config = {
                method: endpointConfig.method || 'GET',
                url: url,
                params: endpointConfig.method === 'GET' ? params : undefined,
                data: endpointConfig.method !== 'GET' ? params : undefined
            };

            const response = await this.client.request(config);
            
            if (response.data.error) {
                throw new Error(response.data.error);
            }

            return response.data;
        } catch (error) {
            logger.error(`Erro na consulta ${endpoint}:`, error.message);
            
            if (error.code === 'ECONNABORTED') {
                throw new Error('Timeout na consulta. Tente novamente.');
            }
            
            if (error.response) {
                if (error.response.status === 429) {
                    throw new Error('Muitas consultas. Aguarde um momento.');
                }
                if (error.response.status === 401) {
                    throw new Error('Erro de autenticação na API.');
                }
                if (error.response.status === 404) {
                    throw new Error('Dados não encontrados.');
                }
            }
            
            throw new Error('Erro na consulta. Tente novamente.');
        }
    }

    // Consultas de CPF
    async consultarCPF(cpf) {
        return await this.makeRequest('cpf', { cpf });
    }

    async consultarCPFSUS(cpf) {
        return await this.makeRequest('cpf_sus', { cpf });
    }

    async consultarCPFFull(cpf) {
        return await this.makeRequest('cpf_full', { cpf });
    }

    // Consultas de Telefone
    async consultarTelefone(telefone) {
        return await this.makeRequest('telefone', { telefone });
    }

    async consultarTelefoneFull(telefone) {
        return await this.makeRequest('telefone_full', { telefone });
    }

    // Consultas de Nome
    async consultarNome(nome) {
        return await this.makeRequest('nome', { nome });
    }

    async consultarNomeCEP(nome, cep) {
        return await this.makeRequest('nome_cep', { nome, cep });
    }

    async consultarNomeUF(nome, uf) {
        return await this.makeRequest('nome_uf', { nome, uf });
    }

    async consultarNomeDataNasc(nome, dataNasc) {
        return await this.makeRequest('nome_data_nasc', { nome, data_nascimento: dataNasc });
    }

    // Consultas de Mãe
    async consultarMae(nomeMae) {
        return await this.makeRequest('mae', { nome_mae: nomeMae });
    }

    async consultarMaeFull(nomeMae) {
        return await this.makeRequest('mae_full', { nome_mae: nomeMae });
    }

    // Consulta de Email
    async consultarEmail(email) {
        return await this.makeRequest('email', { email });
    }

    // Consultas de CEP
    async consultarCEP(cep) {
        return await this.makeRequest('cep', { cep });
    }

    async consultarCEPFull(cep) {
        return await this.makeRequest('cep_full', { cep });
    }

    // Consultas de Documentos
    async consultarRG(rg) {
        return await this.makeRequest('rg', { rg });
    }

    async consultarPIS(pis) {
        return await this.makeRequest('pis', { pis });
    }

    async consultarCNS(cns) {
        return await this.makeRequest('cns', { cns });
    }

    // Consultas Financeiras
    async consultarScore(cpf) {
        return await this.makeRequest('score', { cpf });
    }

    async consultarRenda(cpf) {
        return await this.makeRequest('renda', { cpf });
    }

    async consultarPoderAquisitivo(cpf) {
        return await this.makeRequest('poder_aquisitivo', { cpf });
    }

    // Consulta Título Eleitor
    async consultarTituloEleitor(cpf) {
        return await this.makeRequest('titulo_eleitor', { cpf });
    }

    // Consulta Chave PIX
    async consultarChavePix(cpf) {
        return await this.makeRequest('chave_pix', { cpf });
    }

    // Consultas Veiculares
    async consultarPlaca(placa) {
        return await this.makeRequest('placa', { placa });
    }

    async consultarChassi(chassi) {
        return await this.makeRequest('chassi', { chassi });
    }

    async consultarMotor(motor) {
        return await this.makeRequest('motor', { motor });
    }

    async consultarRenavam(renavam) {
        return await this.makeRequest('renavam', { renavam });
    }

    // Consulta Foto Condutor
    async consultarFotoCondutor(estado, cpf) {
        return await this.makeRequest('foto_condutor', { estado, cpf });
    }
}

module.exports = ConsultaApi;
