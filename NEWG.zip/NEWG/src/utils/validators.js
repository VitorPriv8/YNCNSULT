const logger = require('../services/logger');

/**
 * Valida CPF
 * @param {string} cpf - CPF para validar
 * @returns {boolean} - True se válido
 */
function validateCPF(cpf) {
    if (!cpf) return false;
    
    // Remove caracteres especiais
    cpf = cpf.replace(/[^\d]/g, '');
    
    // Verifica se tem 11 dígitos
    if (cpf.length !== 11) return false;
    
    // Verifica se todos os dígitos são iguais
    if (/^(\d)\1{10}$/.test(cpf)) return false;
    
    // Validação do algoritmo do CPF
    let sum = 0;
    let remainder;
    
    for (let i = 1; i <= 9; i++) {
        sum += parseInt(cpf.substring(i - 1, i)) * (11 - i);
    }
    
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf.substring(9, 10))) return false;
    
    sum = 0;
    for (let i = 1; i <= 10; i++) {
        sum += parseInt(cpf.substring(i - 1, i)) * (12 - i);
    }
    
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf.substring(10, 11))) return false;
    
    return true;
}

/**
 * Valida telefone
 * @param {string} phone - Telefone para validar
 * @returns {boolean} - True se válido
 */
function validatePhone(phone) {
    if (!phone) return false;
    
    // Remove caracteres especiais
    phone = phone.replace(/[^\d]/g, '');
    
    // Verifica se tem entre 10 e 13 dígitos (considerando código do país)
    if (phone.length < 10 || phone.length > 13) return false;
    
    // Padrões brasileiros comuns
    const patterns = [
        /^55\d{10,11}$/, // Com código do país (55)
        /^\d{10,11}$/, // Sem código do país
    ];
    
    return patterns.some(pattern => pattern.test(phone));
}

/**
 * Valida email
 * @param {string} email - Email para validar
 * @returns {boolean} - True se válido
 */
function validateEmail(email) {
    if (!email) return false;
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Valida placa de veículo (padrão antigo e Mercosul)
 * @param {string} placa - Placa para validar
 * @returns {boolean} - True se válido
 */
function validatePlaca(placa) {
    if (!placa) return false;
    
    // Remove espaços e converte para maiúsculo
    placa = placa.replace(/\s/g, '').toUpperCase();
    
    // Padrão antigo: ABC1234
    const oldPattern = /^[A-Z]{3}\d{4}$/;
    
    // Padrão Mercosul: ABC1D23
    const mercosulPattern = /^[A-Z]{3}\d[A-Z]\d{2}$/;
    
    return oldPattern.test(placa) || mercosulPattern.test(placa);
}

/**
 * Valida CEP
 * @param {string} cep - CEP para validar
 * @returns {boolean} - True se válido
 */
function validateCEP(cep) {
    if (!cep) return false;
    
    // Remove caracteres especiais
    cep = cep.replace(/[^\d]/g, '');
    
    // Verifica se tem 8 dígitos
    return cep.length === 8;
}

/**
 * Valida RG
 * @param {string} rg - RG para validar
 * @returns {boolean} - True se válido
 */
function validateRG(rg) {
    if (!rg) return false;
    
    // Remove caracteres especiais
    rg = rg.replace(/[^\dXx]/g, '');
    
    // RG deve ter entre 7 e 9 caracteres
    return rg.length >= 7 && rg.length <= 9;
}

/**
 * Valida PIS
 * @param {string} pis - PIS para validar
 * @returns {boolean} - True se válido
 */
function validatePIS(pis) {
    if (!pis) return false;
    
    // Remove caracteres especiais
    pis = pis.replace(/[^\d]/g, '');
    
    // Verifica se tem 11 dígitos
    if (pis.length !== 11) return false;
    
    // Verifica se todos os dígitos são iguais
    if (/^(\d)\1{10}$/.test(pis)) return false;
    
    // Validação do algoritmo do PIS
    const weights = [3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    let sum = 0;
    
    for (let i = 0; i < 10; i++) {
        sum += parseInt(pis[i]) * weights[i];
    }
    
    const remainder = sum % 11;
    const digit = remainder < 2 ? 0 : 11 - remainder;
    
    return digit === parseInt(pis[10]);
}

module.exports = {
    validateCPF,
    validatePhone,
    validateEmail,
    validatePlaca,
    validateCEP,
    validateRG,
    validatePIS
};
