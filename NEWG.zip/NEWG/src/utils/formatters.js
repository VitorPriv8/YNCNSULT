const logger = require('../services/logger');

/**
 * Formata a resposta da API para exibição no WhatsApp
 * @param {string} commandName - Nome do comando executado
 * @param {Object} data - Dados retornados da API
 * @returns {string} - Resposta formatada
 */
function formatResponse(commandName, data) {
    try {
        if (!data || (typeof data === 'object' && Object.keys(data).length === 0)) {
            return '❌ Nenhum dado encontrado para a consulta realizada.';
        }

        // Se há uma mensagem de erro nos dados
        if (data.error) {
            return `❌ Erro: ${data.error}`;
        }

        switch (commandName) {
            case 'cpf':
                return formatCPFBasico(data);
            
            case 'cpfsus':
                return formatCPFSUS(data);
            
            case 'cpffull':
                return formatCPFFull(data);
            
            case 'telefone':
            case 'telefone2':
                return formatTelefone(data);
            
            case 'nome':
            case 'nome2':
            case 'nome3':
            case 'nome4':
                return formatNome(data);
            
            case 'mae':
            case 'mae2':
                return formatMae(data);
            
            case 'email':
                return formatEmail(data);
            
            case 'cep':
            case 'cep2':
                return formatCEP(data);
            
            case 'rg':
                return formatRG(data);
            
            case 'pis':
                return formatPIS(data);
            
            case 'cns':
                return formatCNS(data);
            
            case 'score':
                return formatScore(data);
            
            case 'renda':
                return formatRenda(data);
            
            case 'poderaquisitivo':
                return formatPoderAquisitivo(data);
            
            case 'titulo':
                return formatTituloEleitor(data);
            
            case 'chavepix':
                return formatChavePix(data);
            
            case 'placa':
                return formatPlaca(data);
            
            case 'chassi':
                return formatChassi(data);
            
            case 'motor':
                return formatMotor(data);
            
            case 'renavam':
                return formatRenavam(data);
            
            case 'foto':
                return formatFotoCondutor(data);
            
            default:
                return formatGeneric(data);
        }
    } catch (error) {
        logger.error('Erro ao formatar resposta:', error);
        return '❌ Erro ao processar os dados retornados.';
    }
}

function formatCPFBasico(data) {
    return `📊 *CONSULTA CPF BÁSICO*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `📅 *Data Nascimento:* ${data.data_nascimento || 'N/A'}\n` +
           `👩 *Nome da Mãe:* ${data.nome_mae || 'N/A'}\n` +
           `📍 *Situação:* ${data.situacao || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatCPFSUS(data) {
    return `🏥 *CONSULTA CPF SUS*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `🆔 *CNS:* ${data.cns || 'N/A'}\n` +
           `📅 *Data Nascimento:* ${data.data_nascimento || 'N/A'}\n` +
           `👩 *Nome da Mãe:* ${data.nome_mae || 'N/A'}\n` +
           `📍 *Município:* ${data.municipio || 'N/A'}\n` +
           `🏛️ *Estado:* ${data.uf || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatCPFFull(data) {
    let response = `🔍 *CONSULTA CPF COMPLETA*\n\n`;
    
    if (data.dados_pessoais) {
        response += `👤 *DADOS PESSOAIS*\n`;
        response += `Nome: ${data.dados_pessoais.nome || 'N/A'}\n`;
        response += `Data Nascimento: ${data.dados_pessoais.data_nascimento || 'N/A'}\n`;
        response += `Nome da Mãe: ${data.dados_pessoais.nome_mae || 'N/A'}\n`;
        response += `Sexo: ${data.dados_pessoais.sexo || 'N/A'}\n\n`;
    }
    
    if (data.endereco) {
        response += `📍 *ENDEREÇO*\n`;
        response += `${data.endereco.logradouro || 'N/A'}\n`;
        response += `${data.endereco.numero || ''} ${data.endereco.complemento || ''}\n`;
        response += `${data.endereco.bairro || 'N/A'}\n`;
        response += `${data.endereco.cidade || 'N/A'} - ${data.endereco.uf || 'N/A'}\n`;
        response += `CEP: ${data.endereco.cep || 'N/A'}\n\n`;
    }
    
    response += `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
    return response;
}

function formatTelefone(data) {
    return `📞 *CONSULTA TELEFONE*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `📞 *Telefone:* ${data.telefone || 'N/A'}\n` +
           `🏢 *Operadora:* ${data.operadora || 'N/A'}\n` +
           `📍 *Estado:* ${data.uf || 'N/A'}\n` +
           `🏙️ *Cidade:* ${data.cidade || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatNome(data) {
    let response = `👤 *CONSULTA POR NOME*\n\n`;
    
    if (Array.isArray(data.resultados)) {
        data.resultados.slice(0, 5).forEach((pessoa, index) => {
            response += `*${index + 1}.* ${pessoa.nome || 'N/A'}\n`;
            response += `CPF: ${pessoa.cpf || 'N/A'}\n`;
            response += `Nascimento: ${pessoa.data_nascimento || 'N/A'}\n`;
            response += `Mãe: ${pessoa.nome_mae || 'N/A'}\n\n`;
        });
        
        if (data.resultados.length > 5) {
            response += `_E mais ${data.resultados.length - 5} resultados..._\n\n`;
        }
    } else {
        response += `👤 *Nome:* ${data.nome || 'N/A'}\n`;
        response += `🆔 *CPF:* ${data.cpf || 'N/A'}\n`;
        response += `📅 *Data Nascimento:* ${data.data_nascimento || 'N/A'}\n`;
        response += `👩 *Nome da Mãe:* ${data.nome_mae || 'N/A'}\n\n`;
    }
    
    response += `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
    return response;
}

function formatMae(data) {
    return `👩 *CONSULTA NOME DA MÃE*\n\n` +
           `👩 *Nome da Mãe:* ${data.nome_mae || 'N/A'}\n` +
           `👤 *Filho(a):* ${data.nome_filho || 'N/A'}\n` +
           `🆔 *CPF:* ${data.cpf || 'N/A'}\n` +
           `📅 *Data Nascimento:* ${data.data_nascimento || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatEmail(data) {
    return `📧 *CONSULTA EMAIL*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `📧 *Email:* ${data.email || 'N/A'}\n` +
           `🆔 *CPF:* ${data.cpf || 'N/A'}\n` +
           `📞 *Telefone:* ${data.telefone || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatCEP(data) {
    return `📍 *CONSULTA CEP*\n\n` +
           `🏠 *Logradouro:* ${data.logradouro || 'N/A'}\n` +
           `🏘️ *Bairro:* ${data.bairro || 'N/A'}\n` +
           `🏙️ *Cidade:* ${data.localidade || 'N/A'}\n` +
           `🏛️ *UF:* ${data.uf || 'N/A'}\n` +
           `📮 *CEP:* ${data.cep || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatRG(data) {
    return `🆔 *CONSULTA RG*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `🆔 *RG:* ${data.rg || 'N/A'}\n` +
           `🏛️ *Órgão Expedidor:* ${data.orgao_expedidor || 'N/A'}\n` +
           `📅 *Data Expedição:* ${data.data_expedicao || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatPIS(data) {
    return `🆔 *CONSULTA PIS*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `🆔 *PIS:* ${data.pis || 'N/A'}\n` +
           `📅 *Data Cadastro:* ${data.data_cadastro || 'N/A'}\n` +
           `📍 *Situação:* ${data.situacao || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatCNS(data) {
    return `🏥 *CONSULTA CNS*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `🆔 *CNS:* ${data.cns || 'N/A'}\n` +
           `📅 *Data Nascimento:* ${data.data_nascimento || 'N/A'}\n` +
           `👩 *Nome da Mãe:* ${data.nome_mae || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatScore(data) {
    return `📊 *CONSULTA SCORE*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `📊 *Score:* ${data.score || 'N/A'}\n` +
           `📈 *Faixa:* ${data.faixa || 'N/A'}\n` +
           `📅 *Data Consulta:* ${data.data_consulta || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatRenda(data) {
    return `💰 *CONSULTA RENDA*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `💰 *Renda Estimada:* ${data.renda_estimada || 'N/A'}\n` +
           `📊 *Classe Social:* ${data.classe_social || 'N/A'}\n` +
           `📅 *Data Consulta:* ${data.data_consulta || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatPoderAquisitivo(data) {
    return `💳 *CONSULTA PODER AQUISITIVO*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `💳 *Poder Aquisitivo:* ${data.poder_aquisitivo || 'N/A'}\n` +
           `📊 *Perfil:* ${data.perfil || 'N/A'}\n` +
           `💰 *Renda Presumida:* ${data.renda_presumida || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatTituloEleitor(data) {
    return `🗳️ *CONSULTA TÍTULO ELEITOR*\n\n` +
           `👤 *Nome:* ${data.nome || 'N/A'}\n` +
           `🗳️ *Título:* ${data.titulo_eleitor || 'N/A'}\n` +
           `📍 *Zona:* ${data.zona || 'N/A'}\n` +
           `📍 *Seção:* ${data.secao || 'N/A'}\n` +
           `🏙️ *Município:* ${data.municipio || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatChavePix(data) {
    let response = `🔑 *CONSULTA CHAVES PIX*\n\n`;
    response += `👤 *Nome:* ${data.nome || 'N/A'}\n`;
    response += `🆔 *CPF:* ${data.cpf || 'N/A'}\n\n`;
    
    if (data.chaves_pix && Array.isArray(data.chaves_pix)) {
        response += `🔑 *Chaves PIX encontradas:*\n`;
        data.chaves_pix.forEach((chave, index) => {
            response += `${index + 1}. ${chave.tipo || 'N/A'}: ${chave.chave || 'N/A'}\n`;
        });
    } else {
        response += `❌ Nenhuma chave PIX encontrada.\n`;
    }
    
    response += `\n_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
    return response;
}

function formatPlaca(data) {
    return `🚗 *CONSULTA PLACA VEÍCULO*\n\n` +
           `🚗 *Placa:* ${data.placa || 'N/A'}\n` +
           `🏭 *Marca/Modelo:* ${data.marca || 'N/A'} ${data.modelo || 'N/A'}\n` +
           `📅 *Ano:* ${data.ano_modelo || 'N/A'}/${data.ano_fabricacao || 'N/A'}\n` +
           `🎨 *Cor:* ${data.cor || 'N/A'}\n` +
           `⛽ *Combustível:* ${data.combustivel || 'N/A'}\n` +
           `📍 *UF:* ${data.uf || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatChassi(data) {
    return `🔧 *CONSULTA CHASSI*\n\n` +
           `🔧 *Chassi:* ${data.chassi || 'N/A'}\n` +
           `🚗 *Marca/Modelo:* ${data.marca || 'N/A'} ${data.modelo || 'N/A'}\n` +
           `📅 *Ano:* ${data.ano_modelo || 'N/A'}/${data.ano_fabricacao || 'N/A'}\n` +
           `🎨 *Cor:* ${data.cor || 'N/A'}\n` +
           `🚗 *Placa:* ${data.placa || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatMotor(data) {
    return `⚙️ *CONSULTA MOTOR*\n\n` +
           `⚙️ *Motor:* ${data.numero_motor || 'N/A'}\n` +
           `🚗 *Marca/Modelo:* ${data.marca || 'N/A'} ${data.modelo || 'N/A'}\n` +
           `📅 *Ano:* ${data.ano_modelo || 'N/A'}/${data.ano_fabricacao || 'N/A'}\n` +
           `🔧 *Chassi:* ${data.chassi || 'N/A'}\n` +
           `🚗 *Placa:* ${data.placa || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatRenavam(data) {
    return `📋 *CONSULTA RENAVAM*\n\n` +
           `📋 *RENAVAM:* ${data.renavam || 'N/A'}\n` +
           `🚗 *Marca/Modelo:* ${data.marca || 'N/A'} ${data.modelo || 'N/A'}\n` +
           `📅 *Ano:* ${data.ano_modelo || 'N/A'}/${data.ano_fabricacao || 'N/A'}\n` +
           `🚗 *Placa:* ${data.placa || 'N/A'}\n` +
           `👤 *Proprietário:* ${data.proprietario || 'N/A'}\n\n` +
           `_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
}

function formatFotoCondutor(data) {
    let response = `📷 *CONSULTA FOTO CONDUTOR*\n\n`;
    response += `👤 *Nome:* ${data.nome || 'N/A'}\n`;
    response += `🆔 *CPF:* ${data.cpf || 'N/A'}\n`;
    response += `🏛️ *Estado:* ${data.estado || 'N/A'}\n`;
    
    if (data.foto_url) {
        response += `📷 *Foto:* ${data.foto_url}\n`;
    } else {
        response += `❌ Foto não disponível\n`;
    }
    
    response += `\n_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
    return response;
}

function formatGeneric(data) {
    let response = `📋 *RESULTADO DA CONSULTA*\n\n`;
    
    if (typeof data === 'object') {
        Object.entries(data).forEach(([key, value]) => {
            if (value !== null && value !== undefined && value !== '') {
                response += `*${key.replace(/_/g, ' ').toUpperCase()}:* ${value}\n`;
            }
        });
    } else {
        response += `${data}\n`;
    }
    
    response += `\n_Consulta realizada em ${new Date().toLocaleString('pt-BR')}_`;
    return response;
}

module.exports = {
    formatResponse
};
