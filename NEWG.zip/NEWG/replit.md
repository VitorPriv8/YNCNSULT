# IsaRobot WhatsApp Bot

## Overview

IsaRobot is a WhatsApp bot designed to provide data consultation services through various query types including CPF, phone numbers, names, and other personal information lookups. The bot integrates with external APIs to fetch and format data for users through WhatsApp messaging.

**Status**: Funcionalmente completo e operacional. Bot configurado com todos os 24 comandos de consulta, incluindo consultas de CPF, telefone, nome, documentos, dados financeiros e veículos. Sistema de rate limiting e validação implementado.

## Recent Changes (July 20, 2025)

✓ Migração para conexão via API REST implementada
✓ Sistema de seleção de método de conexão criado (api.spiderx.com.br)
✓ Integração com API SpiderX para conexão via código de pareamento
✓ Compatibilidade completa com Termux implementada
✓ Menu interativo para escolha de método de conexão (API/QR/Pareamento)
✓ Sistema de configuração via tokens alteráveis (.env)
✓ Documentação completa para setup no Termux (TERMUX_SETUP.md)
✓ Detecção automática de ambiente Termux
✓ Arquitetura modular com API Connection e Connection Selector
✓ Sistema de heartbeat e reconexão automática

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Architecture
The application follows a modular Node.js architecture with clear separation of concerns:

- **Entry Point**: `index.js` serves as the main application entry point with process management
- **Bot Layer**: WhatsApp integration using Baileys library for WhatsApp Web protocol
- **Command Processing**: Centralized command handling with validation and rate limiting
- **API Integration**: External API client for data consultation services
- **Utilities**: Validation and formatting helpers for data processing

### Technology Stack
- **Runtime**: Node.js
- **WhatsApp Integration**: @whiskeysockets/baileys (WhatsApp Web API)
- **HTTP Client**: Axios for external API calls
- **Logging**: Winston for structured logging
- **Error Handling**: @hapi/boom for HTTP error management

## Key Components

### 1. WhatsApp Bot (`src/bot/whatsapp.js`)
- Manages WhatsApp connection and authentication
- Handles QR code generation for initial setup
- Processes incoming messages and routes to command handler
- Implements connection recovery and reconnection logic
- Uses multi-file auth state for persistent sessions

### 2. Command Handler (`src/commands/commandHandler.js`)
- Processes user commands with configurable prefix (default: `/`)
- Implements rate limiting per user to prevent abuse
- Validates command parameters using utility functions
- Routes commands to appropriate API endpoints
- Returns formatted responses to users

### 3. API Service (`src/services/consultaApi.js`)
- Centralized HTTP client for external API integration
- Configurable base URL, API key, and timeout settings
- Request/response interceptors for logging
- Endpoint configuration loaded from JSON files
- Error handling and retry logic

### 4. Validation System (`src/utils/validators.js`)
- CPF validation with algorithm verification
- Phone number format validation
- Email format validation
- License plate validation
- Input sanitization and formatting

### 5. Response Formatting (`src/utils/formatters.js`)
- Command-specific response formatting
- Structured data presentation for WhatsApp
- Error message formatting
- Data sanitization for display

## Data Flow

1. **Message Reception**: WhatsApp messages received through Baileys library
2. **Command Parsing**: Messages parsed to extract commands and parameters
3. **Validation**: Input validation using utility functions
4. **Rate Limiting**: User request frequency checking
5. **API Request**: External API call through consultation service
6. **Response Formatting**: Data formatted for WhatsApp display
7. **Message Delivery**: Formatted response sent back to user

## External Dependencies

### WhatsApp Integration
- **@whiskeysockets/baileys**: WhatsApp Web protocol implementation
- Requires QR code scanning for initial authentication
- Maintains session state in local auth directory

### External APIs
- Configurable API base URL through environment variables
- Bearer token authentication
- Multiple consultation endpoints for different data types
- Rate limiting and timeout handling

### Logging Infrastructure
- Winston logger with multiple transports
- File-based logging with rotation
- Console output for development
- Structured logging with timestamps and levels

## Deployment Strategy

### Environment Configuration
- API credentials and endpoints via environment variables
- Configurable log levels and output directories
- Rate limiting and timeout settings
- Bot command prefix customization

### Process Management
- Graceful shutdown handling (SIGINT/SIGTERM)
- Uncaught exception handling with process exit
- Automatic reconnection for WhatsApp disconnections
- Session persistence across restarts

### File Structure
- Authentication state stored in `/auth` directory
- Logs written to `/logs` directory with rotation
- Configuration files in `/config` directory
- Modular source code organization in `/src`

### Error Handling
- Comprehensive error logging with stack traces
- API error propagation and user notification
- Connection failure recovery mechanisms
- Input validation error messages

The bot is designed to be resilient and maintainable, with clear separation between WhatsApp communication, business logic, and external integrations. The modular architecture allows for easy extension of commands and API integrations.