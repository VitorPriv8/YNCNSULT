# 📱 Configuração para Termux

Este guia explica como configurar e executar o IsaRobot WhatsApp Bot no Termux.

## 🚀 Instalação Inicial

### 1. Instalar Dependências do Sistema

```bash
# Atualizar repositórios
pkg update && pkg upgrade -y

# Instalar Node.js e outras dependências
pkg install nodejs-lts git ffmpeg wget curl -y

# Verificar instalação
node --version
npm --version
```

### 2. Clonar o Projeto

```bash
# Navegar para armazenamento interno
cd /storage/emulated/0

# Clonar repositório
git clone https://github.com/seu-usuario/isarobot-whatsapp-bot.git
cd isarobot-whatsapp-bot

# Dar permissões de acesso ao armazenamento
termux-setup-storage
```

### 3. Instalar Dependências do Node.js

```bash
npm install
```

## ⚙️ Configuração

### 1. Configurar Variáveis de Ambiente

Edite o arquivo `.env`:

```bash
nano .env
```

Configure as seguintes variáveis:

```env
# Configurações do Bot WhatsApp
BOT_NAME=IsaRobot
BOT_PREFIX=/

# API de Consultas
API_BASE_URL=https://api.consultas.com
API_KEY=SEU_TOKEN_API_AQUI
API_TIMEOUT=30000

# API WhatsApp Connection
WHATSAPP_API_URL=https://api.spiderx.com.br
API_TOKEN=SEU_TOKEN_SPIDERX_AQUI
WEBHOOK_URL=

# Configurações de Conexão
CONNECTION_METHOD=api
# Opções: api, baileys_qr, baileys_pairing
PHONE_NUMBER=5511999999999

# Rate Limiting
RATE_LIMIT_WINDOW=60000
RATE_LIMIT_MAX_REQUESTS=10

# Logs
LOG_LEVEL=info
LOG_FILE=logs/bot.log

# Estados para consulta de fotos
ESTADOS_FOTO=CE,PR,ES,RJ
```

### 2. Configurar Tokens

#### Token SpiderX API:
1. Acesse [https://api.spiderx.com.br](https://api.spiderx.com.br)
2. Registre-se e obtenha seu token
3. Substitua `SEU_TOKEN_SPIDERX_AQUI` pelo token real

#### Token API de Consultas:
1. Configure sua API de consultas
2. Substitua `SEU_TOKEN_API_AQUI` pelo token real

## 🎮 Execução

### Iniciar o Bot

```bash
node index.js
```

### Métodos de Conexão

O bot oferece 3 métodos de conexão:

1. **API REST (Recomendado para Termux)**
   - Usa api.spiderx.com.br
   - Conecta via código de pareamento
   - Mais estável em ambientes móveis

2. **QR Code (Baileys)**
   - Conexão direta via QR code
   - Funciona bem em desktop

3. **Código de Pareamento (Baileys)**
   - Conexão direta via código
   - Alternativa ao QR code

### Menu Interativo

Ao executar `node index.js`, você verá:

```
🤖 IsaRobot WhatsApp Bot - Configuração de Conexão

📡 Selecione o método de conexão:

1️⃣  Conexão via API REST (Recomendado)
    └─ Usa api.spiderx.com.br com código de pareamento
2️⃣  Conexão via QR Code (Baileys)
    └─ Conexão direta via QR code
3️⃣  Conexão via Código de Pareamento (Baileys)
    └─ Conexão direta via código
4️⃣  Configurações
5️⃣  Sair

Escolha uma opção (1-5):
```

## 🔧 Resolução de Problemas

### Problema: Node.js desatualizado

```bash
# Atualizar Node.js
pkg uninstall nodejs
pkg install nodejs-lts
```

### Problema: Permissões de arquivo

```bash
# Dar permissões corretas
chmod +x index.js
chmod -R 755 src/
```

### Problema: Falta de espaço

```bash
# Limpar cache npm
npm cache clean --force

# Verificar espaço disponível
df -h
```

### Problema: Erro de conexão

1. Verificar conexão com internet
2. Testar conectividade:

```bash
ping google.com
curl -I https://api.spiderx.com.br
```

## 📋 Comandos Úteis

### Manter Bot Rodando em Background

```bash
# Instalar screen
pkg install screen

# Criar sessão
screen -S isarobot

# Executar bot
node index.js

# Sair da sessão (Ctrl+A, depois D)
# Voltar à sessão
screen -r isarobot
```

### Logs e Monitoramento

```bash
# Ver logs em tempo real
tail -f logs/bot.log

# Ver últimas 50 linhas do log
tail -n 50 logs/bot.log

# Verificar uso de recursos
top
```

### Backup de Configurações

```bash
# Backup da configuração
cp .env .env.backup

# Backup dos dados de autenticação
tar -czf auth_backup.tar.gz auth/
```

## 🛡️ Segurança

### Proteger Tokens

```bash
# Verificar permissões do .env
ls -la .env

# Restringir permissões (somente leitura para owner)
chmod 600 .env
```

### Logs Seguros

```bash
# Limpar logs antigos (manter últimos 7 dias)
find logs/ -name "*.log" -mtime +7 -delete
```

## 🚀 Otimizações para Termux

### 1. Configurar Swap (se necessário)

```bash
# Verificar memória
free -h

# Criar arquivo swap de 1GB (se necessário)
fallocate -l 1G /data/data/com.termux/files/home/swapfile
chmod 600 ~/swapfile
mkswap ~/swapfile
swapon ~/swapfile
```

### 2. Otimizar Node.js para Mobile

Adicione ao início do index.js:

```javascript
// Otimizações para Termux
if (process.env.PREFIX && process.env.PREFIX.includes('termux')) {
    process.env.NODE_OPTIONS = '--max-old-space-size=512';
}
```

### 3. Auto-inicialização

Crie script de inicialização:

```bash
nano ~/start-bot.sh
```

```bash
#!/bin/bash
cd ~/isarobot-whatsapp-bot
node index.js
```

```bash
chmod +x ~/start-bot.sh
```

## 📞 Suporte

Em caso de problemas:

1. Verificar logs: `tail -f logs/bot.log`
2. Testar conectividade
3. Verificar configurações do .env
4. Reiniciar o Termux
5. Consultar documentação da API

## 🔄 Atualizações

Para atualizar o bot:

```bash
# Backup da configuração
cp .env .env.backup

# Atualizar código
git pull origin main

# Reinstalar dependências
npm install

# Restaurar configuração
cp .env.backup .env
```