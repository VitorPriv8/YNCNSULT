require('dotenv').config();
const ConnectionSelector = require('./src/bot/connectionSelector');
const logger = require('./src/services/logger');
const commandHandler = require('./src/commands/commandHandler');

class BotManager {
    constructor() {
        this.connection = null;
        this.connectionType = null;
        this.bot = null;
    }

    async start() {
        try {
            // Verificar se está no Termux
            if (ConnectionSelector.isTermux()) {
                ConnectionSelector.checkTermuxDependencies();
            }

            logger.info('🤖 Iniciando IsaRobot WhatsApp Bot...');
            
            // Mostrar informações do sistema
            this.showSystemInfo();
            
            // Selecionar método de conexão
            const connectionSelector = new ConnectionSelector();
            const result = await connectionSelector.start();
            
            this.connection = result.connection;
            this.connectionType = result.type;
            
            logger.info(`✅ Conexão estabelecida via ${this.connectionType}`);
            
            // Configurar handlers de mensagem
            await this.setupMessageHandlers();
            
            // Manter o processo rodando
            this.keepAlive();
            
        } catch (error) {
            logger.error('Erro ao iniciar o bot:', error);
            process.exit(1);
        }
    }

    showSystemInfo() {
        console.log('\n' + '='.repeat(60));
        console.log('🤖 IsaRobot WhatsApp Bot v1.0');
        console.log('📅 Data:', new Date().toLocaleString('pt-BR'));
        console.log('💻 Node.js:', process.version);
        console.log('🏃 PID:', process.pid);
        console.log('📱 Termux:', ConnectionSelector.isTermux() ? 'Sim' : 'Não');
        console.log('='.repeat(60) + '\n');
    }

    async setupMessageHandlers() {
        if (this.connectionType === 'api') {
            // Para conexão via API, implementar webhook ou polling
            await this.setupAPIHandlers();
        } else {
            // Para conexão Baileys, usar eventos
            await this.setupBaileysHandlers();
        }
    }

    async setupAPIHandlers() {
        // TODO: Implementar servidor webhook ou polling para receber mensagens da API
        logger.info('📡 Configurando handlers para API REST...');
        
        // Por enquanto, apenas log
        setInterval(async () => {
            if (this.connection && this.connection.isConnected()) {
                const status = await this.connection.getConnectionStatus();
                if (!status.connected) {
                    logger.warn('Conexão API perdida, tentando reconectar...');
                }
            }
        }, 30000); // Verificar a cada 30 segundos
    }

    async setupBaileysHandlers() {
        logger.info('🔧 Configurando handlers para Baileys...');
        
        if (this.connection && this.connection.ev) {
            this.connection.ev.on('messages.upsert', async (m) => {
                await this.handleMessage(m);
            });
        }
    }

    async handleMessage(messageUpdate) {
        try {
            const message = messageUpdate.messages[0];
            if (!message.message || message.key.fromMe) return;

            const messageText = this.extractMessageText(message);
            if (!messageText) return;

            const chatId = message.key.remoteJid;
            const senderId = message.key.participant || chatId;

            logger.info(`📩 Mensagem recebida de ${senderId}: ${messageText}`);

            // Processar comando
            const response = await commandHandler.processCommand(messageText, senderId);
            
            if (response) {
                await this.sendMessage(chatId, response);
            }
        } catch (error) {
            logger.error('Erro ao processar mensagem:', error);
        }
    }

    extractMessageText(message) {
        if (message.message.conversation) {
            return message.message.conversation;
        }
        if (message.message.extendedTextMessage) {
            return message.message.extendedTextMessage.text;
        }
        return null;
    }

    async sendMessage(chatId, text) {
        try {
            if (this.connectionType === 'api') {
                await this.connection.sendMessage(chatId, text);
            } else {
                await this.connection.sendMessage(chatId, { text });
            }
            
            logger.info(`📤 Mensagem enviada para ${chatId}`);
        } catch (error) {
            logger.error('Erro ao enviar mensagem:', error);
        }
    }

    keepAlive() {
        logger.info('🔄 Bot ativo e aguardando mensagens...');
        
        // Manter o processo rodando
        process.stdin.resume();
        
        // Heartbeat log a cada 5 minutos
        setInterval(() => {
            const uptime = process.uptime();
            const hours = Math.floor(uptime / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            logger.info(`💓 Bot ativo - Uptime: ${hours}h ${minutes}m`);
        }, 300000); // 5 minutos
    }

    async gracefulShutdown() {
        logger.info('🛑 Iniciando encerramento gracioso...');
        
        try {
            if (this.connection) {
                if (this.connectionType === 'api') {
                    await this.connection.disconnect();
                } else if (this.connection.ws) {
                    await this.connection.ws.close();
                }
            }
            
            logger.info('✅ Bot encerrado com sucesso');
            process.exit(0);
        } catch (error) {
            logger.error('Erro no encerramento:', error);
            process.exit(1);
        }
    }
}

// Instanciar e iniciar o bot
const botManager = new BotManager();

// Handlers para encerramento gracioso
process.on('SIGINT', () => {
    console.log('\n🛑 Recebido SIGINT...');
    botManager.gracefulShutdown();
});

process.on('SIGTERM', () => {
    console.log('\n🛑 Recebido SIGTERM...');
    botManager.gracefulShutdown();
});

process.on('uncaughtException', (error) => {
    logger.error('Exceção não capturada:', error);
    botManager.gracefulShutdown();
});

process.on('unhandledRejection', (reason, promise) => {
    logger.error('Promise rejeitada não tratada:', reason);
    botManager.gracefulShutdown();
});

// Iniciar o bot
botManager.start();
